BRASILÉ — VERSION STRIPE READY

Le site utilise Stripe Checkout avec une fonction serveur sécurisée.
Le prix est contrôlé côté serveur : 70 € par veste. Le navigateur ne peut pas modifier le prix.

MISE EN LIGNE :
1. Crée un compte Stripe.
2. Sur Vercel, importe ce dossier comme projet.
3. Dans Vercel > Settings > Environment Variables, ajoute :
   STRIPE_SECRET_KEY = ta clé secrète Stripe
   SITE_URL = https://ton-domaine.fr
4. Redéploie le site.
5. Teste d'abord avec la clé Stripe de test (sk_test_...).
6. Quand tout fonctionne, remplace par la clé live (sk_live_...).

NE METS JAMAIS STRIPE_SECRET_KEY dans index.html, GitHub ou un fichier public.

Le checkout demande l'adresse de livraison et accepte actuellement France, Belgique, Espagne, Portugal, Allemagne, Italie et Pays-Bas.
