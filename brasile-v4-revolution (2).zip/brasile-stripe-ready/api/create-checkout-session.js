export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Méthode non autorisée" });
  }

  try {
    const { items } = req.body || {};
    const allowed = {
      "Brasil Black": "Veste noire Brasil",
      "Brasil Mint": "Veste verte Brasil",
      "Brasil Cream": "Veste crème Brasil"
    };

    if (!Array.isArray(items) || !items.length || items.length > 20) {
      return res.status(400).json({ error: "Panier invalide" });
    }

    // Never trust the browser for the price: every product is priced here at 70 €.
    const line_items = items.map((item) => {
      if (!allowed[item.name] || !["S", "M", "L"].includes(item.size)) {
        throw new Error("Article ou taille invalide");
      }

      return {
        price_data: {
          currency: "eur",
          product_data: {
            name: `${item.name} — taille ${item.size}`,
            description: allowed[item.name]
          },
          unit_amount: 7000
        },
        quantity: 1
      };
    });

    const origin = req.headers.origin || process.env.SITE_URL;
    if (!origin) throw new Error("SITE_URL manquant");

    const params = new URLSearchParams();
    params.append("mode", "payment");
    params.append("success_url", `${origin}/success.html`);
    params.append("cancel_url", `${origin}/index.html`);
    params.append("billing_address_collection", "required");
    params.append("shipping_address_collection[allowed_countries][0]", "FR");
    params.append("shipping_address_collection[allowed_countries][1]", "BE");
    params.append("shipping_address_collection[allowed_countries][2]", "ES");
    params.append("shipping_address_collection[allowed_countries][3]", "PT");
    params.append("shipping_address_collection[allowed_countries][4]", "DE");
    params.append("shipping_address_collection[allowed_countries][5]", "IT");
    params.append("shipping_address_collection[allowed_countries][6]", "NL");

    line_items.forEach((item, i) => {
      params.append(`line_items[${i}][price_data][currency]`, item.price_data.currency);
      params.append(`line_items[${i}][price_data][product_data][name]`, item.price_data.product_data.name);
      params.append(`line_items[${i}][price_data][product_data][description]`, item.price_data.product_data.description);
      params.append(`line_items[${i}][price_data][unit_amount]`, item.price_data.unit_amount);
      params.append(`line_items[${i}][quantity]`, item.quantity);
    });

    const stripeResponse = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.STRIPE_SECRET_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: params
    });

    const session = await stripeResponse.json();
    if (!stripeResponse.ok) {
      return res.status(502).json({ error: session.error?.message || "Stripe a refusé la demande" });
    }

    return res.status(200).json({ url: session.url });
  } catch (error) {
    return res.status(400).json({ error: error.message || "Erreur serveur" });
  }
}
